# PRODIGY_DS_01-Intern-Pinaki-Jupyter-Lab-TASK-01
As an Intern, I have created and completed in 12-14 days in Jupyter Lab as per the task of Prodigy InfoTech i.e., DATA SCIENCE ----TASK 1. 
Task : Create a bar chart or histogram to visualize the distribution of a categorical or continuous variable, such as the distribution of ages or genders in a population.


https://github.com/PINAKIMATHAN/PRODIGY_DS_01-Intern-Pinaki-Jupyter-Lab-TASK-01/assets/107812574/02db8f9c-e1d3-40fa-9557-adb86b9fc38b

